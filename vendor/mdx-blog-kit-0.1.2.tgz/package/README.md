# mdx-blog-kit

Headless MDX blog mechanics for small Next.js sites that keep posts in their
own repositories.

`mdx-blog-kit` is not a CMS. It does not render React, store content, run
a queue, expose an admin UI, or mutate deployed apps. It gives each site a small
shared core for the repetitive parts of MDX blogging:

- Parse MDX files and normalize frontmatter.
- Hide drafts and future-dated posts until `publishedAt <= now`.
- Preserve host-specific frontmatter through adapter hooks.
- Generate visible slugs, tag summaries, pagination, RSS, and sitemap entries.
- Verify that a published post is live on article, index, RSS, and sitemap
  surfaces.
- Submit IndexNow only after proof succeeds.
- Fail closed when required proof or IndexNow config is missing.

## Install

Current distribution is a private GitHub tag:

```bash
pnpm add mdx-blog-kit@github:basedbuilder/mdx-blog-kit#v0.1.1
```

Because the repo is private, CI/deploy builders need GitHub credentials that can
fetch `basedbuilder/mdx-blog-kit`. For a public registry release, publish and
install strategy must be decided explicitly first.

## Requirements

- Node.js 20+
- ESM project
- `pnpm`

The package has one runtime dependency: `gray-matter`.

## Frontmatter

Base fields:

```yaml
---
title: "Post title"
description: "Short description"
publishedAt: "2026-05-28T09:00:00.000Z"
updatedAt: "2026-05-28T12:00:00.000Z"
status: "published"
tags:
  - Guides
canonicalUrl: "https://example.com/blog/post-title"
noindex: false
heroImage: "/images/post-title/hero.webp"
heroImageAlt: "Screenshot of the workflow"
---
```

Required: `title`, `description`, `publishedAt`.

Defaults:

- `status` defaults to `"published"`.
- `tags` defaults to `[]`.
- `routeBase` defaults to `"/blog"`.
- `postsPerPage` defaults to `12`.

Visibility:

- A post is visible when `status === "published"` and `publishedAt <= now`.
- Drafts and future posts are excluded from normal lists, RSS, sitemap, and
  visible slug helpers.
- In development, loaders include drafts by default unless the host passes
  `includeDrafts: false`.

## Basic Usage

```ts
import path from "node:path"
import { createMdxBlog } from "mdx-blog-kit"

export const blog = createMdxBlog({
  contentDir: path.join(process.cwd(), "content/blog"),
  baseUrl: "https://example.com",
})

export async function getAllPostMetadata() {
  return blog.getAllPosts({ includeDrafts: false })
}

export async function getPostSourceBySlug(slug: string) {
  return blog.getVisiblePostSourceBySlug(slug)
}
```

`getPostSourceBySlug` returns raw MDX body plus metadata. Compile and render the
MDX in the host app so each site can keep its own components, styling, and MDX
pipeline.

## Host-Specific Frontmatter

Use `mapFrontmatter` to add product-specific fields while keeping the shared
base rules:

```ts
import { createMdxBlog, coerceString } from "mdx-blog-kit"

type CodewertExtra = {
  category?: string
  readTime?: string
}

export const blog = createMdxBlog({
  contentDir: "content/blog",
  baseUrl: "https://codewert.de",
  mapFrontmatter(raw) {
    return {
      extra: {
        category: coerceString(raw.category),
        readTime: coerceString(raw.readTime),
      } satisfies CodewertExtra,
    }
  },
})
```

Use `validatePost` for host-only policy:

```ts
import { assertPublishable, createMdxBlog } from "mdx-blog-kit"

export const blog = createMdxBlog({
  contentDir: "content/blog",
  baseUrl: "https://gameslike.co",
  validatePost(post) {
    if (post.status === "published") {
      assertPublishable(post)
    }
  },
})
```

`assertPublishable` requires published posts to have `heroImage`,
`heroImageAlt`, and not use `/opengraph-image.png` as the hero.

## API

```ts
const blog = createMdxBlog(config)
```

Returned helpers:

- `invalidateCaches()`
- `getAllPosts({ includeDrafts? })`
- `getVisiblePosts(now?)`
- `getPostSourceBySlug(slug, { includeDrafts? })`
- `getVisiblePostSourceBySlug(slug, now?)`
- `getVisibleSlugs(now?)`
- `getTags(now?)`
- `getPaginatedPosts(page, now?, pageSize?)`
- `renderRss(now, options)`
- `getSitemapEntries(now?)`

Named exports also include:

- `normalizeBaseFrontmatter`
- `assertPublishable`
- `isPublishedAtDue`
- `paginatePosts`
- `getTagSummaries`
- `renderRss`
- `getSitemapEntries`
- `renderSitemapXml`
- `loadSiteContract`
- `verifyPublishedPost`
- `proveAndSubmitIndexNow`
- `submitIndexNow`

## RSS

```ts
export async function GET() {
  const xml = await blog.renderRss(new Date(), {
    title: "Example Blog",
    description: "Latest posts from Example.",
    language: "en",
  })

  return new Response(xml, {
    headers: {
      "Content-Type": "application/rss+xml; charset=utf-8",
      "Cache-Control": "public, max-age=900, stale-while-revalidate=3600",
    },
  })
}
```

## Sitemap

```ts
import { renderSitemapXml } from "mdx-blog-kit"

export async function GET() {
  const entries = await blog.getSitemapEntries()
  return new Response(renderSitemapXml(entries), {
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
    },
  })
}
```

## Publish Proof Contract

Create `blogkit.site.json` in each host app:

```json
{
  "siteId": "example",
  "baseUrl": "https://example.com",
  "routeBase": "/blog",
  "proof": {
    "article": "https://example.com/blog/{slug}",
    "index": "https://example.com/blog",
    "rss": "https://example.com/blog/rss",
    "sitemap": "https://example.com/sitemap.xml"
  },
  "indexNow": {
    "keyFile": "public/indexnow.txt",
    "keyLocation": "https://example.com/indexnow.txt"
  }
}
```

Proof passes only when every surface returns a successful HTTP response and the
body contains the exact article path or article URL.

## CLI

Submit IndexNow:

```bash
pnpm indexnow:submit -- --dry-run https://example.com/blog/post-slug
```

Recommended host scripts:

```json
{
  "scripts": {
    "blogkit:prove": "mdx-blog-kit prove --contract blogkit.site.json",
    "indexnow:submit": "mdx-blog-kit indexnow submit --key-file public/indexnow.txt"
  }
}
```

Commands:

```bash
mdx-blog-kit prove --contract blogkit.site.json --slug post-slug
mdx-blog-kit prove-and-index --contract blogkit.site.json --slug post-slug
mdx-blog-kit indexnow submit --key-file public/indexnow.txt --dry-run https://example.com/blog/post-slug
```

All commands print JSON. Failures exit non-zero and print a JSON error object to
stderr.

## Scheduled Publishing Model

The intended publishing flow:

1. Commit a week of MDX posts to the host app.
2. Future-dated posts are deployed early but hidden by `publishedAt`.
3. On publish day, run:

```bash
pnpm blogkit:prove -- --slug post-slug
pnpm indexnow:submit -- https://example.com/blog/post-slug
```

There is no deployed blog revalidation endpoint. Publish-day work is read-only
proof plus IndexNow submission.

## Development

```bash
pnpm install
pnpm test
pnpm typecheck
pnpm lint
pnpm build
pnpm pack --dry-run
```

Build output in `dist/` is committed because host apps install from GitHub tags.

## Release

1. Run the full validation commands.
2. Build `dist/`.
3. Commit source and `dist/`.
4. Tag the commit.
5. Push the commit and tag only when explicitly requested.
6. Update host apps to the new tag and rerun their blog tests, IndexNow dry run,
   and full validation gates.

Keep the repository private unless Alex explicitly asks for public visibility
and confirms it again in the same thread.
